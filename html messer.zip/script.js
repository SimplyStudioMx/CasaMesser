const observer = new IntersectionObserver((entries) => entries.forEach((entry) => {
  if (entry.isIntersecting) entry.target.classList.add('in-view');
}), { threshold: 0.14 });
document.querySelectorAll('.manifesto, .experience-card, .quote, .visit').forEach((el) => observer.observe(el));
